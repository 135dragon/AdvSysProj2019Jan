/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advsysprojfinal;

import Appointment.*;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
//import java.util.Date;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 *
 * @author aasim
 */
public class CalVBox extends VBox {

    private final DBConnector dbconn = new DBConnector();
    private final Statement stmt = dbconn.getStmt();
    ArrayList<Appointment> list = new ArrayList<>(0);
    private final DatePicker datePicker = new DatePicker();

    TableView tableView = new TableView();
    private String dayOfWeek;

    CalVBox() {
        fillListsWeek();
        setSelf();

    }

    private void setSelf() {

        BorderPane pane = new BorderPane();
        String temp = "";
        VBox grid2 = new VBox();
        Button search = new Button("Search Appointments");
        Button weeklyAppointments = new Button("This Week's Appointments");
        Button add = new Button("Add Appointment");
        Button help = new Button("Help");

        AppointmentCreator x = new AppointmentCreator();
        add.setOnAction(e -> x.start());

        grid2.setPadding(new Insets(0, 15, 15, 15));
        grid2.getChildren().addAll(datePicker, search, weeklyAppointments, add, help);

        //
        this.getChildren().clear();
        this.setPadding(new Insets(15, 12, 15, 12));
        this.setAlignment(Pos.TOP_LEFT);
        this.setSpacing(5);

        //
        TableColumn<Integer, Appointment> column1 = new TableColumn<>("Appointment ID");
        column1.setCellValueFactory(new PropertyValueFactory<>("apptId"));

        TableColumn<Integer, Appointment> column2 = new TableColumn<>("Patient ID");
        column2.setCellValueFactory(new PropertyValueFactory<>("patId"));

        TableColumn<Integer, Appointment> column3 = new TableColumn<>("Doctor ID");
        column3.setCellValueFactory(new PropertyValueFactory<>("docId"));

        TableColumn<Date, Appointment> column4 = new TableColumn<>("Date");
        column4.setCellValueFactory(new PropertyValueFactory<>("date"));

        TableColumn<String, Appointment> column5 = new TableColumn<>("Results");
        column5.setCellValueFactory(new PropertyValueFactory<>("results"));

        TableColumn<Times, Appointment> column6 = new TableColumn<>("Time of Appointment");
        column6.setCellValueFactory(new PropertyValueFactory<>("time"));
        tableView.setEditable(true);
        tableView.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {

                    System.out.println(tableView.getSelectionModel().getSelectedItem());

                }
            }
        });

        tableView.getColumns().add(column4);
        tableView.getColumns().add(column1);
        tableView.getColumns().add(column2);
        tableView.getColumns().add(column3);
        tableView.getColumns().add(column6);
        tableView.getColumns().add(column5);

        pane.setLeft(grid2);
        pane.setCenter(tableView);
        this.getChildren().add(pane);

        weeklyAppointments.setOnMousePressed((MouseEvent event) -> {
            fillListsWeek();
        });
        search.setOnMousePressed((MouseEvent event) -> {
            java.util.Date date;
            fillList();
        });
    }

    private void fillListsWeek() {
        list.clear();
        int ida = 0;
        int idb = 0;
        int idc = 0;
        Date date;
        Times time;
        String result;
        try {
            String queryString = "SELECT * FROM Appointments WHERE (((Appointments.appDate) Between Date()-6 And Date()+6));";
            ResultSet resultSet = stmt.executeQuery(queryString);
            ResultSetMetaData rsMetaData = resultSet.getMetaData();

            while (resultSet.next()) {
                for (int i = 1; i < rsMetaData.getColumnCount(); i = i + 15) {
                    ida = resultSet.getInt(i);
                    idb = resultSet.getInt(i + 1);
                    idc = resultSet.getInt(i + 2);
                    date = resultSet.getDate(i + 3);
//                    time = new Times(resultSet.getBoolean(i + 4), resultSet.getBoolean(i + 5), resultSet.getBoolean(i + 6), resultSet.getBoolean(i + 7), resultSet.getBoolean(i + 8), resultSet.getBoolean(i + 9), resultSet.getBoolean(i + 10), resultSet.getBoolean(i + 11), resultSet.getBoolean(i + 12), resultSet.getBoolean(i + 13), resultSet.getBoolean(i + 14));
                    Times asz = new Times();

                    result = resultSet.getString(i + 15);
                    list.add(new Appointment(ida, idb, idc, date, asz, result));

                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(CalVBox.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void fillList() {
        list.clear();

        int ida = 0;
        int idb = 0;
        int idc = 0;
        Date date;
        Times time;
        String result;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
            String queryString = "SELECT * FROM Appointments WHERE (((Appointments.appDate) = #" + formatter.format(datePicker.getValue()) + "#));";
            ResultSet resultSet = stmt.executeQuery(queryString);
            ResultSetMetaData rsMetaData = resultSet.getMetaData();

            while (resultSet.next()) {
                for (int i = 1; i < rsMetaData.getColumnCount(); i = i + 15) {
                    ida = resultSet.getInt(i);
                    idb = resultSet.getInt(i + 1);
                    idc = resultSet.getInt(i + 2);
                    date = resultSet.getDate(i + 3);
//                    time = new Times(resultSet.getBoolean(i + 4), resultSet.getBoolean(i + 5), resultSet.getBoolean(i + 6), resultSet.getBoolean(i + 7), resultSet.getBoolean(i + 8), resultSet.getBoolean(i + 9), resultSet.getBoolean(i + 10), resultSet.getBoolean(i + 11), resultSet.getBoolean(i + 12), resultSet.getBoolean(i + 13), resultSet.getBoolean(i + 14));
                    Times asz = new Times();

                    result = resultSet.getString(i + 15);
                    list.add(new Appointment(ida, idb, idc, date, asz, result));

                }
            }
            tableView.getItems().setAll(list);
        } catch (SQLException ex) {
            Logger.getLogger(CalVBox.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }
}
