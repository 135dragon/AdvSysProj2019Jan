/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advsysprojfinal;

import java.io.FileNotFoundException;
import java.sql.Statement;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

import javafx.stage.Stage;

/**
 *
 * @author aasim
 */
public class AdvSysProjFinal extends Application {

    BorderPane root = new BorderPane();
    HBox top, bottom;
    VBox left = new VBox(), right = new VBox();

    LoginVBox login = new LoginVBox();
    DocVBox docCenter = new DocVBox();
    PatVBox patCenter = new PatVBox();
    CalVBox calCenter = new CalVBox();
    private final DBConnector dbconn = new DBConnector();
    private final Statement stmt = dbconn.getStmt();

    @Override
    public void start(Stage primaryStage) {

        //Menu
        Menu menu1 = new Menu("Doctors");
        Menu docView = new Menu("View Doctors");
        Menu menu2 = new Menu("Patients");
        Menu patView = new Menu("View Patients");
        Menu menu3 = new Menu("Calendar");
        Menu calView = new Menu("View Calendar");
        Menu menu4 = new Menu("Admin Only");
        Menu register = new Menu("Register new user");

        menu1.getItems().addAll(docView);
        menu2.getItems().addAll(patView);
        menu3.getItems().addAll(calView);
        menu4.getItems().addAll(register);

        MenuBar menuBar = new MenuBar(menu1, menu2, menu3, menu4);
        VBox main = new VBox(menuBar, root);

        try {
            top = createTop();
            root.setTop(top);
        } catch (FileNotFoundException e) {
            System.out.println("Err");
        }
        root.setCenter(login);
        root.setBottom(bottom);
        root.setRight(right);

        Scene scene = new Scene(main, 1000, 1000);

        primaryStage.setTitle("Welcome to the new world");
        primaryStage.setScene(scene);
        primaryStage.show();

        patView.setOnAction((ActionEvent event) -> {
            if (login.getSignedIn()) {
                patCenter();
            } else {
                alert("Please Sign In");
            }

        });
        docView.setOnAction((ActionEvent event) -> {
            if (login.getSignedIn()) {
                docCenter();
            } else {
                alert("Please Sign In");
            }

        });
        calView.setOnAction((ActionEvent event) -> {
            if (login.getSignedIn()) {
                calCenter();
            } else {
                alert("Please Sign In");
            }

        });
        register.setOnAction((ActionEvent event) -> {
            if (login.getSignedIn()) {
                //
                if (login.isAdmin()) {
                    registerCenter();
                } else {
                    alert("You need to be an admin to do that!");
                }

            } else {
                alert("Please Sign In");
            }

        });

    }

    public HBox createTop() throws FileNotFoundException {
        HBox hbox = new HBox();
        hbox.setPadding(new Insets(15, 12, 15, 12));
        hbox.setSpacing(10);
        hbox.setStyle("-fx-background-color: #107076;");
        // Image

        // Text
        Text t = new Text("Name");
        t.setFont(Font.font("Verdana", FontPosture.ITALIC, 20));
        t.setFill(Color.WHITE);
        //

        hbox.getChildren().addAll(t);

        return hbox;
    }   //Done. All I have to do is change the image

    //This function clears current center and updates it to the center displaying all patients
    public void patCenter() {
        root.setCenter(patCenter);
    }

    //This function clears current center and updates it to the center displaying all doctors
    //
    public void docCenter() {
        root.setCenter(docCenter);
    }

    //
    public void registerCenter() {
    }

    //This function clears current center and updates it to the center displaying the calendar
    public void calCenter() {
        System.out.println("calCenter launched");
        root.setCenter(calCenter);
    }

    public void alert(String x) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Wait a second...");
        alert.setHeaderText(x);
        alert.showAndWait();
    }

    //
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
