/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advsysprojfinal;

import java.util.Date;

/**
 *
 * @author aasim
 */
public class Times {

    protected boolean time7, time8, time9, time10, time11, time12, time13, time14, time15, time16, time17;

    Times() {

    }

    Times(boolean time7a, boolean time8a, boolean time9a, boolean time10a, boolean time11a, boolean time12a, boolean time13a, boolean time14a, boolean time15a, boolean time16a, boolean time17a) {
        time7 = time7a;
        time8 = time8a;
        time9 = time9a;
        time10 = time10a;
        time11 = time11a;
        time12 = time12a;
        time13 = time13a;
        time14 = time14a;
        time15 = time15a;
        time16 = time16a;
        time17 = time17a;
    }

    @Override
    public String toString() {
        String x = new String("From ");
        String init, fin;
        init = "";
        fin = "";
        if (time7) {
            init = "7 to ";
            if (time8) {
                fin = "8";
            } else if (time9) {
                fin = "9";
            } else if (time10) {
                fin = "10";
            } else if (time11) {
                fin = "11";
            } else if (time12) {
                fin = "12";
            } else if (time13) {
                fin = "1";
            } else if (time14) {
                fin = "2";
            } else if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time8) {
            init = "8 to ";
            if (time9) {
                fin = "9";
            } else if (time10) {
                fin = "10";
            } else if (time11) {
                fin = "11";
            } else if (time12) {
                fin = "12";
            } else if (time13) {
                fin = "1";
            } else if (time14) {
                fin = "2";
            } else if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time9) {
            init = "9 to ";
            if (time10) {
                fin = "10";
            } else if (time11) {
                fin = "11";
            } else if (time12) {
                fin = "12";
            } else if (time13) {
                fin = "1";
            } else if (time14) {
                fin = "2";
            } else if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time10) {
            init = "10 to ";
            if (time11) {
                fin = "11";
            } else if (time12) {
                fin = "12";
            } else if (time13) {
                fin = "1";
            } else if (time14) {
                fin = "2";
            } else if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time11) {
            init = "11 to ";
            if (time12) {
                fin = "12";
            } else if (time13) {
                fin = "1";
            } else if (time14) {
                fin = "2";
            } else if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time12) {
            init = "12 to ";
            if (time13) {
                fin = "1";
            } else if (time14) {
                fin = "2";
            } else if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time13) {
            init = "1 to ";
            if (time14) {
                fin = "2";
            } else if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time14) {
            init = "2 to ";
            if (time15) {
                fin = "3";
            } else if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time15) {
            init = "3 to ";

            if (time16) {
                fin = "4";
            } else if (time17) {
                fin = "5";
            }
        } else if (time16) {
            init = "4 to ";
            if (time17) {
                fin = "5";
            }
        }

        return x + init + fin;
    }
}
