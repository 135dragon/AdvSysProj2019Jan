/**
 * Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
 *
 * You may not modify, use, reproduce, or distribute this software except in
 * compliance with  the terms of the License at:
 * http://java.net/projects/javaeetutorial/pages/BerkeleyLicense
 */
package javaeetutorial.dukesbookstore.web.managedbeans;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javaeetutorial.dukesbookstore.ejb.BookRequestBean;
import javaeetutorial.dukesbookstore.exception.OrderException;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIOutput;
import javax.faces.component.UISelectBoolean;
import javax.faces.model.SelectItem;
import javax.inject.Named;
import javaeetutorial.dukesbookstore.ejb.StateTaxRequestBean;
import javaeetutorial.dukesbookstore.entity.StateTax;

@Named
@RequestScoped
public class CashierBean extends AbstractBean {

    private static final long serialVersionUID = -9221440716172304017L;
    @EJB
    BookRequestBean bookRequestBean;
    // Add ons for tax 
    @EJB
    StateTaxRequestBean stateTaxRequestBean;
    
    private String stringProperty = "";
    private String[] newsletters;
    private static final SelectItem[] newsletterItems = {new SelectItem("Duke's Quarterly"), new SelectItem("Innovator's Almanac"), new SelectItem("Duke's Diet and Exercise Journal"), new SelectItem("Random Ramblings")};
    private String name = null;
    private String creditCardNumber = null;
    private Date shipDate;
    private String shippingOption = "2";
    public CashierBean() {
        this.newsletters = new String[0];
    }
    private double stateTaxOption;
    double subtotal = 0.00,taxRate = 0.00,shippingCost = 0.00,finalTotal = 0.00;
    UIOutput specialOfferText = null, thankYou = null;
    UISelectBoolean specialOffer = null;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public void setNewsletters(String[] newsletters) {
        this.newsletters = newsletters;
    }

    public String[] getNewsletters() {
        return this.newsletters;
    }

    public SelectItem[] getNewsletterItems() {
        return newsletterItems;
    }

    public Date getShipDate() {
        return this.shipDate;
    }

    public void setShipDate(Date shipDate) {
        this.shipDate = shipDate;
    }

    public void setShippingOption(String shippingOption) {
        this.shippingOption = shippingOption;
    }

    public String getShippingOption() {
        return this.shippingOption;
    }
    
    //Adding shipping cost
    
    public double getShippingCost() 
    {
        int selectedShipping = Integer.parseInt(shippingOption); 
        
        switch (selectedShipping) {
            case 2:
                this.shippingCost = 19.99;
                return shippingCost;
            case 5:
                this.shippingCost = 11.97;
                return shippingCost;
            default:
                this.shippingCost = 0.00;
                return shippingCost;
        }
    }
        
    public UIOutput getSpecialOfferText() {
        return this.specialOfferText;
    }

    public void setSpecialOfferText(UIOutput specialOfferText) {
        this.specialOfferText = specialOfferText;
    }

    public UISelectBoolean getSpecialOffer() {
        return this.specialOffer;
    }

    public void setSpecialOffer(UISelectBoolean specialOffer) {
        this.specialOffer = specialOffer;
    }

    public UIOutput getThankYou() {
        return this.thankYou;
    }

    public void setThankYou(UIOutput thankYou) {
        this.thankYou = thankYou;
    }

    public String getStringProperty() {
        return (this.stringProperty);
    }

    public void setStringProperty(String stringProperty) {
        this.stringProperty = stringProperty;
    }

    public String submit() {
        // Calculate and save the ship date
        int days = Integer.valueOf(shippingOption).intValue();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, days);
        setShipDate(cal.getTime());

        if ((cart.getTotal() > 100.00) && !specialOffer.isRendered()) {
            specialOfferText.setRendered(true);
            specialOffer.setRendered(true);

            return null;
        } else if (specialOffer.isRendered() && !thankYou.isRendered()) {
            thankYou.setRendered(true);

            return null;
        } else {
            try {
                bookRequestBean.updateInventory(cart);
            } catch (OrderException ex) {
                return "bookordererror";
            }
            
            
            //Added functionality for tax 

            this.subtotal = cart.getTotal();
            
            cart.clear();
            
            return ("confirmorder");
            
            //cart.clear();

            //return ("bookreceipt");
        }
    }
    
    // Methods added for tax 

    public List<StateTax> getStateTax() 
    {
        return stateTaxRequestBean.getStateTax();
    }

    public double getStateTaxOption() 
    {
        return stateTaxOption;
    }
    
    public void setStateTaxOption(double stateTaxOption) 
    {
        this.stateTaxOption = stateTaxOption;
    }

    public double getSubtotal() 
    {
        return subtotal;
    }
    
    public double getTaxRate() 
    {
        taxRate = getSubtotal() * getStateTaxOption();
        return taxRate;
    }
    
    public double getFinalTotal() 
    {
        this.finalTotal = getSubtotal() + getTaxRate() + getShippingCost();
        return finalTotal;
    }
    
    
}