//Class based on BookRequestBean.java

package javaeetutorial.dukesbookstore.ejb;

import java.util.List;
import javaeetutorial.dukesbookstore.entity.StateTax;
import javax.ejb.EJBException;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateful
public class StateTaxRequestBean 
{
    @PersistenceContext
    private EntityManager entityManager;

    public StateTaxRequestBean() throws Exception 
    {
    
    }

    public void defineTax(String taxState, double tax)
    {
        try {
            StateTax stateTax = new StateTax(taxState, tax);
            entityManager.persist(stateTax);
        } catch (Exception ex) {
            throw new EJBException(ex.getMessage());
        }
    }

    public List<StateTax> getStateTax()
    {
        return (List<StateTax>) entityManager.createNamedQuery("findTax").getResultList();
    }
}