//Class based on ConfigBran.java

package javaeetutorial.dukesbookstore.ejb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

@Singleton
@Startup
public class StateTaxConfigBean 
{
    @EJB
    private StateTaxRequestBean stateTaxRequestBean;
    @PostConstruct
    public void createData() 
    {
        //Tax extracted from https://en.wikipedia.org/wiki/Sales_taxes_in_the_United_States#By_jurisdiction
        stateTaxRequestBean.defineTax("Alabama", 0.04);
        stateTaxRequestBean.defineTax("Alaska", 0.00);
        stateTaxRequestBean.defineTax("Arizona", 0.056);
        stateTaxRequestBean.defineTax("Arkansas", 0.065);
        stateTaxRequestBean.defineTax("California", 0.0725);
        stateTaxRequestBean.defineTax("Colorado", 0.029);
        stateTaxRequestBean.defineTax("Connecticut", 0.0635);
        stateTaxRequestBean.defineTax("Delaware", 0.00);
        stateTaxRequestBean.defineTax("District of Columbia", 0.0575);
        stateTaxRequestBean.defineTax("Florida", 0.06);
        stateTaxRequestBean.defineTax("Georgia", 0.04);
        stateTaxRequestBean.defineTax("Hawaii", 0.04166);
        stateTaxRequestBean.defineTax("Idaho", 0.06);
        stateTaxRequestBean.defineTax("Illinois", 0.0625);
        stateTaxRequestBean.defineTax("Indiana", 0.07);
        stateTaxRequestBean.defineTax("Iowa", 0.06);
        stateTaxRequestBean.defineTax("Kansas", 0.065);
        stateTaxRequestBean.defineTax("Kentucky", 0.06);
        stateTaxRequestBean.defineTax("Louisiana", 0.05);
        stateTaxRequestBean.defineTax("Maine", 0.055);
        stateTaxRequestBean.defineTax("Maryland", 0.06);
        stateTaxRequestBean.defineTax("Massachusetts", 0.0625);
        stateTaxRequestBean.defineTax("Michigan", 0.06);
        stateTaxRequestBean.defineTax("Minnesota", 0.06875);
        stateTaxRequestBean.defineTax("Mississippi", 0.07);
        stateTaxRequestBean.defineTax("Missouri", 0.04225);
        stateTaxRequestBean.defineTax("Montana", 0.00);
        stateTaxRequestBean.defineTax("Nebraska", 0.055);
        stateTaxRequestBean.defineTax("Nevada", 0.0685);
        stateTaxRequestBean.defineTax("New Hampshire", 0.00);
        stateTaxRequestBean.defineTax("New Jersey", 0.06625);
        stateTaxRequestBean.defineTax("New Mexico", 0.05125);
        stateTaxRequestBean.defineTax("New York", 0.04);
        stateTaxRequestBean.defineTax("North Carolina", 0.0475);
        stateTaxRequestBean.defineTax("North Dakota", 0.05);
        stateTaxRequestBean.defineTax("Ohio", 0.0575);
        stateTaxRequestBean.defineTax("Oklahoma", 0.045);
        stateTaxRequestBean.defineTax("Oregon", 0.00);
        stateTaxRequestBean.defineTax("Pennsylvania", 0.06);
        stateTaxRequestBean.defineTax("Puerto Rico", 0.15);
        stateTaxRequestBean.defineTax("Rhode Island", 0.07);
        stateTaxRequestBean.defineTax("South Carolina", 0.06);
        stateTaxRequestBean.defineTax("South Dakota", 0.04);
        stateTaxRequestBean.defineTax("Tennessee", 0.07);
        stateTaxRequestBean.defineTax("Texas", 0.0625);
        stateTaxRequestBean.defineTax("Utah", 0.0595);
        stateTaxRequestBean.defineTax("Vermont", 0.06);
        stateTaxRequestBean.defineTax("Virginia", 0.053);
        stateTaxRequestBean.defineTax("Washington", 0.065);
        stateTaxRequestBean.defineTax("West Virginia", 0.06);
        stateTaxRequestBean.defineTax("Wisconsin", 0.05);
        stateTaxRequestBean.defineTax("Wyoming", 0.04);
    }
}
