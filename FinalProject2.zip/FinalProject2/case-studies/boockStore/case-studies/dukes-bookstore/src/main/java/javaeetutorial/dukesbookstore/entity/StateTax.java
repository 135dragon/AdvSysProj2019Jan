//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package javaeetutorial.dukesbookstore.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(
    name = "STATE_TAX"
)
@NamedQuery(
    name = "findTax",
    query = "SELECT t FROM StateTax t ORDER BY t.taxState"
)
public class StateTax implements Serializable {
    @Id
    @NotNull
    private String taxState;
    private double tax;

    public StateTax() {
    }

    public StateTax(String taxState, double tax) {
        this.taxState = taxState;
        this.tax = tax;
    }

    public String getTaxState() {
        return this.taxState;
    }

    public double getTax() {
        return this.tax;
    }

    public void setTaxState(String taxState) {
        this.taxState = taxState;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public boolean equals(Object object) {
        if(!(object instanceof StateTax)) {
            return false;
        } else {
            StateTax other = (StateTax)object;
            return this.taxState != null || other.taxState == null && this.taxState == null || this.taxState.equals(other.taxState);
        }
    }

    public int hashCode() {
        int hash = 7;
        int hash = 59 * hash + Objects.hashCode(this.taxState);
        return hash;
    }
}
