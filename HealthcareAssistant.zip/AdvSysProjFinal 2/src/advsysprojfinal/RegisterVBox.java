package advsysprojfinal;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author aasim
 */
public class RegisterVBox extends VBox {
    
    String userType = new String();
    
    private final DBConnector dbconn = new DBConnector();
    private final Statement stmt = dbconn.getStmt();
    TextField userName = new TextField();
    TextField passWord = new TextField();
    CheckBox isAdmin = new CheckBox();
    TextArea results = new TextArea();
    
    RegisterVBox() {
        setSelf();
    }
    
    public void setSelf() {
        VBox base = new VBox();
        HBox user = new HBox();
        HBox pass = new HBox();
        Label luser = new Label("Username: ");
        Label lpass = new Label("Password: ");
        
        Button submit = new Button("Create New User");
        Button delete = new Button("Deactivate User.");
        user.getChildren().addAll(luser, userName);
        pass.getChildren().addAll(lpass, passWord);
        HBox buttons = new HBox(submit, delete);
        HBox admin = new HBox(new Label("Is this user an admin?"), isAdmin);
        this.getChildren().addAll(user, pass, admin, buttons, results);
        results.setEditable(false);
        submit.setOnAction((ActionEvent event) -> {
            
            if (userName.getText().isEmpty() || passWord.getText().isEmpty()) {
                results.setText("Please fill in the username and password fields.");
            } else {
                if (checkUserPass(userName.getText())) {
                    
                    addUser();
                    results.setText("User: " + userName.getText() + " successfully created.");
                    
                } else {
                    results.setText("User: " + userName.getText() + " already exists. Please try again.");
                }
            }
        });
        
        delete.setOnAction((ActionEvent event) -> {
            if (userName.getText().isEmpty() || passWord.getText().isEmpty()) {
                results.setText("Please fill in the username and password fields.");
            } else {
                if (checkUserPass(userName.getText())) {
                    
                    deleteUser();
                    results.setText("User: " + userName.getText() + " successfully deleted.");
                    
                } else {
                    results.setText("User: " + userName.getText() + " doesn't exist. Please try again.");
                }
            }
        });
        
    }
    
    public boolean checkUserPass(String user) {
        try {
            String queryString = "SELECT username FROM Users WHERE username = '" + user + "';";
            
            ResultSet resultSet = stmt.executeQuery(queryString);
            
            ResultSetMetaData rsMetaData = resultSet.getMetaData();

            // Iterate through the result and print the student names
            while (resultSet.next()) {
                for (int i = 1; i < rsMetaData.getColumnCount(); i++) {
                    if (((String) resultSet.getObject(i)).equals(user)) {
                        System.out.println("User already exists");
                        return false;
                    } else {
                    }
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(LoginVBox.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return true;
    }
    
    public void addUser() {
        try {
            String queryString = "INSERT INTO Users (username, password, admin) VALUES ('" + userName.getText() + "','" + passWord.getText() + "'," + isAdmin.isSelected() + ");";
            
            stmt.execute(queryString);

            // Iterate through the result and print the student names
        } catch (SQLException ex) {
            Logger.getLogger(LoginVBox.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void deleteUser() {
        try {
            String queryString = "DELETE FROM Users WHERE username = '" + userName.getText() + "';";
            
            stmt.execute(queryString);

            // Iterate through the result and print the student names
        } catch (SQLException ex) {
            Logger.getLogger(LoginVBox.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
