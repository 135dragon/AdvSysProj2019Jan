package advsysprojfinal;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author aasim
 */
public class LoginVBox extends VBox {

    String userType = new String();
    boolean signedIn = false;
    private final DBConnector dbconn = new DBConnector();
    private final Statement stmt = dbconn.getStmt();
    boolean isAdmin = false;

    LoginVBox() {
        setSelf();
    }

    public void setSelf() {
        VBox base = new VBox();
        HBox user = new HBox();
        HBox pass = new HBox();
        Label luser = new Label("Username: ");
        Label lpass = new Label("Password: ");
        TextField userName = new TextField();
        TextField passWord = new TextField();
        Button submit = new Button("Submit");
        user.getChildren().addAll(luser, userName);
        pass.getChildren().addAll(lpass, passWord);
        this.getChildren().addAll(user, pass, submit);

        submit.setOnAction((ActionEvent event) -> {
            if (checkUserPass(userName.getText(), passWord.getText())) {
                this.getChildren().clear();
                this.getChildren().add(new Label("Succesfully Signed in! Please use the menu on top to use the program"));
            }
        });
    }

    public boolean checkUserPass(String user, String pass) {
        try {
            String queryString = "SELECT * FROM Users WHERE username = '" + user + "';";

            ResultSet resultSet = stmt.executeQuery(queryString);

            ResultSetMetaData rsMetaData = resultSet.getMetaData();

            // Iterate through the result and print the names
            while (resultSet.next()) {
                for (int i = 1; i < rsMetaData.getColumnCount(); i = i + 5) {
                    if (((String) resultSet.getObject(i + 2)).equals(pass)) {
                        System.out.println("Good Job");
                        signedIn = true;
                        isAdmin = (Boolean) resultSet.getObject(i + 3);
                        break;
                    } else {
                        System.out.println(resultSet.getObject(i + 1) + " " + resultSet.getObject(i + 2));
                    }
                }

                break;
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoginVBox.class.getName()).log(Level.SEVERE, null, ex);
        }

        return signedIn;
    }

    public boolean getSignedIn() {
        return signedIn;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

}
