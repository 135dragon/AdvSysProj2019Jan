/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advsysprojfinal;

import Appointment.*;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
//import java.util.Date;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

/**
 *
 * @author aasim
 */
public class CalVBox extends VBox {

    private final DBConnector dbconn = new DBConnector();
    private final Statement stmt = dbconn.getStmt();
    ArrayList<Appointment> list = new ArrayList<>(0);
    private final DatePicker datePicker = new DatePicker();
    private int id;

    private final Label patientName = new Label();
    private final TextField tfAddress = new TextField();
    private final TextField tfCity = new TextField();
    private final TextField tfState = new TextField();
    private final TextField tfpNumber = new TextField();
    private final TextField tfZipC = new TextField();
    private final TextField tfResult = new TextField();

    private final Label lPatient = new Label("Patient Name");
    private final Label lAddress = new Label("Address");
    private final Label lCity = new Label("City");
    private final Label lState = new Label("State");
    private final Label lpNumber = new Label("Phone");
    private final Label lZipC = new Label("ZipCode");

    boolean test = true;

    ComboBox specialitiesList = new ComboBox();

    CheckBox cbMonday = new CheckBox();
    CheckBox cbTuesday = new CheckBox();
    CheckBox cbWednesday = new CheckBox();
    CheckBox cbThursday = new CheckBox();
    CheckBox cbFriday = new CheckBox();
    CheckBox cbTime7 = new CheckBox();
    CheckBox cbTime8 = new CheckBox();
    CheckBox cbTime9 = new CheckBox();
    CheckBox cbTime10 = new CheckBox();
    CheckBox cbTime11 = new CheckBox();
    CheckBox cbTime12 = new CheckBox();
    CheckBox cbTime13 = new CheckBox();
    CheckBox cbTime14 = new CheckBox();
    CheckBox cbTime15 = new CheckBox();
    CheckBox cbTime16 = new CheckBox();
    CheckBox cbTime17 = new CheckBox();

    Alert docAlert = new Alert(Alert.AlertType.INFORMATION);
    Alert docDoesntWork = new Alert(Alert.AlertType.INFORMATION);

    private TableColumn<Appointment, Integer> column1;
    private TableColumn<Appointment, Integer> column2;
    private TableColumn<Appointment, Integer> column3;
    private TableColumn<Appointment, Date> column4;
    private TableColumn<Appointment, String> column5;
    private TableColumn<Appointment, Times> column6;

    private String speciality;

    TableView<Appointment> tableView = new TableView<Appointment>();
    private String dayOfWeek;

    CalVBox() {
        fillListsWeek();
        setSelf();

    }

    private void setSelf() {

        BorderPane pane = new BorderPane();
        String temp = "";
        VBox grid2 = new VBox();
        Button search = new Button("Search Appointments");
        Button weeklyAppointments = new Button("This Week's Appointments");
        Button add = new Button("Add Appointment");
        Button help = new Button("Help");
        Button delete = new Button("Delete");
        Button calander = new Button("Calendar");
        Button update = new Button("Update Appointment");

        AppointmentCreator x = new AppointmentCreator();
        add.setOnAction(e -> pane.setCenter(x.appointment()));
        calander.setOnAction(e -> setSelf());

        update.setOnAction((ActionEvent event) -> {
            Appointment appt = tableView.getSelectionModel().getSelectedItem();
            fillInfoAppointment(appt.getApptId());
            EditAppointmentContenets();
        });

        grid2.setPadding(new Insets(0, 15, 15, 15));
        grid2.getChildren().addAll(datePicker, search, weeklyAppointments, add, delete, update, calander, help);

        //
        this.getChildren().clear();
        this.setPadding(new Insets(15, 12, 15, 12));
        this.setAlignment(Pos.TOP_LEFT);
        this.setSpacing(5);

        //
        if (test) {
            column1 = new TableColumn<>("Appointment ID");
            column1.setCellValueFactory(new PropertyValueFactory<>("apptId"));

            column2 = new TableColumn<>("Patient ID");
            column2.setCellValueFactory(new PropertyValueFactory<>("patId"));

            column3 = new TableColumn<>("Doctor ID");
            column3.setCellValueFactory(new PropertyValueFactory<>("docId"));

            column4 = new TableColumn<>("Date");
            column4.setCellValueFactory(new PropertyValueFactory<>("date"));

            column5 = new TableColumn<>("Results");
            column5.setCellValueFactory(new PropertyValueFactory<>("results"));

            column6 = new TableColumn<>("Time of Appointment");
            column6.setCellValueFactory(new PropertyValueFactory<>("time"));

            tableView.getColumns().add(column4);
            tableView.getColumns().add(column1);
            tableView.getColumns().add(column2);
            tableView.getColumns().add(column3);

            tableView.getColumns().add(column5);

        }

        tableView.setEditable(true);
        tableView.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    Appointment sApp = tableView.getSelectionModel().getSelectedItem();
                    showPatientContents(sApp.getPatId());

                    //    showPatientContents(Double.parseDouble(tableView.getSelectionModel().getSelectedItem().toString());
                }
            }
        });

        if (test) {
            test = false;
        }

        delete.setOnAction(e -> deleteAppointment());

        pane.setLeft(grid2);
        pane.setCenter(tableView);
        this.getChildren().add(pane);

        weeklyAppointments.setOnMousePressed((MouseEvent event) -> {
            fillListsWeek();
        });
        search.setOnMousePressed((MouseEvent event) -> {
            java.util.Date date;
            fillList();
        });
    }

    private void showPatientContents(double record) {
        BorderPane pane = new BorderPane();
        TextArea taResult = new TextArea();
        int idNum = (int) Math.round(record);
        Button goBack = new Button("Go Back");
        Button edit = new Button("Edit");
        Button appointments = new Button("Appointments");
        Button help = new Button("Help");
        GridPane grid = new GridPane();
        GridPane grid2 = new GridPane();
        AppointmentCreator a = new AppointmentCreator();
        String name = "";

        taResult.setEditable(false);

        grid.add(goBack, 0, 0);
        grid.add(edit, 1, 0);
        grid.add(appointments, 2, 0);
        grid.add(help, 3, 0);

        grid.setPadding(new Insets(15, 15, 15, 15));
        grid.setHgap(10);
        grid.setVgap(10);

        grid2.setPadding(new Insets(15, 15, 15, 15));
        grid2.setHgap(10);
        grid2.setVgap(10);

        grid2.add(new Label(""), idNum, id);

        this.getChildren().clear();
        this.setPadding(new Insets(15, 12, 15, 12));
        this.setAlignment(Pos.TOP_LEFT);
        this.setSpacing(5);

        try {
            String queryString = "select * from Patient JOIN Appointments ON Patient.ID = Appointments.IDPatient WHERE Patient.ID = " + idNum + " OR Appointments.IDPatient =" + idNum;

            ResultSet resultSet = stmt.executeQuery(queryString);

            ResultSetMetaData rsMetaData = resultSet.getMetaData();

            grid2.add(new Label("ID:"), 0, 0);
            grid2.add(new Label("First Name:"), 0, 1);
            grid2.add(new Label("Last Name:"), 0, 2);
            grid2.add(new Label("Address:"), 0, 3);
            grid2.add(new Label("City:"), 0, 4);
            grid2.add(new Label("State:"), 0, 5);
            grid2.add(new Label("Phone Number:"), 0, 6);
            grid2.add(new Label("Zip Code:"), 0, 7);
            grid2.add(new Label("Date:"), 0, 11);
            grid2.add(new Label("Time:"), 0, 12);
            grid2.add(new Label("Results:"), 0, 13);

            // Iterate through the result and print the student names
            int x = 1;
            while (resultSet.next()) {
                if (x == 1) {
                    for (int i = 1; i <= rsMetaData.getColumnCount(); i++) {
                        if (i != 9 && i != 10 && i != 11 && i < 12) {
                            grid2.add(new Label(resultSet.getNString(i)), x, i - 1);
                            if (rsMetaData.getColumnName(i).equals("fName")) {
                                name = resultSet.getNString(i);
                            }
                            if (rsMetaData.getColumnName(i).equals("lName")) {
                                name += " " + resultSet.getNString(i);
                            }
                        } else if (i == 12) {
                            grid2.add(new Label(resultSet.getNString(i).substring(0, 10)), x, i - 1);
                        } else if (i > 12 && i < 24) {
                            if (resultSet.getNString(i).equals("TRUE")) {
                                if (rsMetaData.getColumnName(i).equals("time7")) {
                                    grid2.add(new Label("7:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time8")) {
                                    grid2.add(new Label("8:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time9")) {
                                    grid2.add(new Label("9:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time10")) {
                                    grid2.add(new Label("10:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time11")) {
                                    grid2.add(new Label("11:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time12")) {
                                    grid2.add(new Label("12:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time13")) {
                                    grid2.add(new Label("13:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time14")) {
                                    grid2.add(new Label("14:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time15")) {
                                    grid2.add(new Label("15:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time16")) {
                                    grid2.add(new Label("16:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time17")) {
                                    grid2.add(new Label("17:00"), x, 12);
                                }
                            }
                        } else if (i == 24) {
                            grid2.add(new Label(resultSet.getNString(i)), x, 13);
                        }
                    }
                } else {
                    for (int i = 12; i <= rsMetaData.getColumnCount(); i++) {
                        if (i == 12) {
                            grid2.add(new Label(resultSet.getNString(i).substring(0, 10)), x, i - 1);
                        } else if (i > 12 && i < 24) {
                            if (resultSet.getNString(i).equals("TRUE")) {
                                if (rsMetaData.getColumnName(i).equals("time7")) {
                                    grid2.add(new Label("7:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time8")) {
                                    grid2.add(new Label("8:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time9")) {
                                    grid2.add(new Label("9:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time10")) {
                                    grid2.add(new Label("10:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time11")) {
                                    grid2.add(new Label("11:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time12")) {
                                    grid2.add(new Label("12:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time13")) {
                                    grid2.add(new Label("13:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time14")) {
                                    grid2.add(new Label("14:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time15")) {
                                    grid2.add(new Label("15:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time16")) {
                                    grid2.add(new Label("16:00"), x, 12);
                                }
                                if (rsMetaData.getColumnName(i).equals("time17")) {
                                    grid2.add(new Label("17:00"), x, 12);
                                }
                            }
                        } else if (i == 24) {
                            grid2.add(new Label(resultSet.getNString(i)), x, 13);
                        }
                    }
                }
                x++;
            }
        } catch (SQLException ex) {
        }

        final String nameF = name;

        pane.setCenter(new ScrollPane(grid2));
        pane.setBottom(grid);
        this.getChildren().add(pane);

        edit.setOnAction(e -> EditPatientContenets(record));
        goBack.setOnAction(e -> setSelf());
        appointments.setOnAction(e -> a.start(nameF));
        help.setOnAction((e -> HelpMenu.helpMenu("ContentPat")));
    }

    public void EditPatientContenets(double record) {

        BorderPane pane = new BorderPane();
        GridPane grid = new GridPane();
        Button btSave = new Button("Save");
        Button btDelete = new Button("Delete");
        Button goBack = new Button("Go Back");
        Button help = new Button("Help");

        this.getChildren().clear();
        this.setPadding(new Insets(15, 12, 15, 12));
        this.setAlignment(Pos.TOP_LEFT);
        this.setSpacing(5);

        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        fillInfoPatient(record);

        grid.add(lPatient, 0, 0);
        grid.add(patientName, 1, 0);
        grid.add(lAddress, 0, 1);
        grid.add(tfAddress, 1, 1);
        grid.add(lCity, 0, 2);
        grid.add(tfCity, 1, 2);
        grid.add(lState, 0, 3);
        grid.add(tfState, 1, 3);
        grid.add(lpNumber, 0, 4);
        grid.add(tfpNumber, 1, 4);
        grid.add(lZipC, 0, 5);
        grid.add(tfZipC, 1, 5);
        grid.add(btSave, 0, 10);
        grid.add(goBack, 1, 10);
        grid.add(btDelete, 2, 10);
        grid.add(help, 3, 10);

        btSave.setOnAction(e -> saveActionPatient());
        btDelete.setOnAction(e -> deleteActionPatient());

        fillInfoDoctor(record);

        pane.setTop(grid);

        this.getChildren().add(pane);

        btSave.setOnAction(e -> saveActionPatient());
        goBack.setOnAction(e -> showPatientContents(record));
        btDelete.setOnAction(e -> deleteActionPatient());
        help.setOnAction((e -> HelpMenu.helpMenu("EditPat")));

    }

    public void EditAppointmentContenets() {

        BorderPane pane = new BorderPane();
        GridPane grid = new GridPane();
        Button btSave = new Button("Save");
        Button goBack = new Button("Go Back");
        Button help = new Button("Help");

        this.getChildren().clear();
        this.setPadding(new Insets(15, 12, 15, 12));
        this.setAlignment(Pos.TOP_LEFT);
        this.setSpacing(5);

        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        grid.add(new Label("7:00"), 0, 0);
        grid.add(cbTime7, 1, 0);
        grid.add(new Label("8:00"), 0, 1);
        grid.add(cbTime8, 1, 1);
        grid.add(new Label("9:00"), 0, 2);
        grid.add(cbTime9, 1, 2);
        grid.add(new Label("10:00"), 0, 3);
        grid.add(cbTime10, 1, 3);
        grid.add(new Label("11:00"), 0, 4);
        grid.add(cbTime11, 1, 4);
        grid.add(new Label("12:00"), 0, 5);
        grid.add(cbTime12, 1, 5);
        grid.add(new Label("1:00"), 0, 6);
        grid.add(cbTime13, 1, 6);
        grid.add(new Label("2:00"), 0, 7);
        grid.add(cbTime14, 1, 7);
        grid.add(new Label("3:00"), 0, 8);
        grid.add(cbTime15, 1, 8);
        grid.add(new Label("4:00"), 0, 9);
        grid.add(cbTime16, 1, 9);
        grid.add(new Label("5:00"), 0, 10);
        grid.add(cbTime17, 1, 10);
        grid.add(new Label("Result"), 0, 11);
        grid.add(tfResult, 1, 11);
        grid.add(btSave, 0, 12);
        grid.add(goBack, 1, 12);
        grid.add(help, 2, 12);

        pane.setTop(grid);

        this.getChildren().add(pane);

        btSave.setOnAction(e -> saveActionAppointment());
        goBack.setOnAction(e -> setSelf());
        help.setOnAction((e -> HelpMenu.helpMenu("EditPat")));

    }

    private void saveActionPatient() {
        System.out.println("SaveActionPat");

        try {
            String queryString2 = "UPDATE Patient SET "
                    + "Address='" + tfAddress.getText() + "', "
                    + "City='" + tfCity.getText() + "', "
                    + "State='" + tfState.getText() + "', "
                    + "pNumber='" + tfpNumber.getText() + "', "
                    + "zipCode='" + tfZipC.getText() + "' "
                    + "WHERE (ID='" + id + "')";
            stmt.executeUpdate(queryString2);

        } catch (SQLException ex) {
        }
        System.out.println("done");
    }

    private void saveActionAppointment() {
        System.out.println("SaveActionAppt");

        try {
            String queryString6 = "UPDATE Appointments SET "
                    + "time7='" + cbTime7.isSelected() + "', "
                    + "time8='" + cbTime8.isSelected() + "', "
                    + "time9='" + cbTime9.isSelected() + "', "
                    + "time10='" + cbTime10.isSelected() + "', "
                    + "time11='" + cbTime11.isSelected() + "', "
                    + "time12='" + cbTime12.isSelected() + "', "
                    + "time13='" + cbTime13.isSelected() + "', "
                    + "time14='" + cbTime14.isSelected() + "', "
                    + "time15='" + cbTime15.isSelected() + "', "
                    + "time16='" + cbTime16.isSelected() + "', "
                    + "time17='" + cbTime17.isSelected() + "', "
                    + "Result='" + tfResult.getText() + "' "
                    + "WHERE (ID='" + id + "')";
            stmt.executeUpdate(queryString6);

        } catch (SQLException ex) {
        }
        System.out.println("done");
    }

    private void deleteActionPatient() {
        try {
            String queryString4 = "DELETE FROM Patient "
                    + "WHERE (ID='" + id + "')";
            stmt.executeUpdate(queryString4);

        } catch (SQLException ex) {
        }
        System.out.println("done");
    }

    private void fillInfoPatient(double record) {
        System.out.println("fillInfoPatient");
        int idNum = (int) Math.round(record);

        try {
            String queryString = "select * from Patient where ID =" + idNum;
            ResultSet resultSet = stmt.executeQuery(queryString);
            while (resultSet.next()) {
                id = resultSet.getInt("ID");
                patientName.setText(resultSet.getString("fName") + " " + resultSet.getString("lName"));
                tfAddress.setText(resultSet.getString("Address"));
                tfCity.setText(resultSet.getString("City"));
                tfState.setText(resultSet.getString("State"));
                tfZipC.setText(resultSet.getString("zipCode"));
                tfpNumber.setText(resultSet.getString("pNumber"));
            }

        } catch (SQLException ex) {
        }
        System.out.println("loaded");
    }

    private void fillInfoDoctor(double record) {

        int idNum = (int) Math.round(record);

        try {
            String queryString = "select * from Doctor where (ID = '" + Integer.toString(idNum) + "')";
            ResultSet resultSet = stmt.executeQuery(queryString);
            while (resultSet.next()) {
                id = idNum;
                cbMonday.setSelected(resultSet.getBoolean("Monday"));
                cbTuesday.setSelected(resultSet.getBoolean("Tuesday"));
                cbWednesday.setSelected(resultSet.getBoolean("Wednesday"));
                cbThursday.setSelected(resultSet.getBoolean("Thursday"));
                cbFriday.setSelected(resultSet.getBoolean("Friday"));
                speciality = resultSet.getString("Speciality");
                chooseSpecialityOption();
                System.out.println(id);
            }

        } catch (SQLException ex) {
        }
        System.out.println("loaded");
    }

    private void fillInfoAppointment(double record) {

        int idNum = (int) Math.round(record);

        try {
            String queryString = "select * from Appointments where (ID = '" + Integer.toString(idNum) + "')";
            ResultSet resultSet = stmt.executeQuery(queryString);
            while (resultSet.next()) {
                id = idNum;
                cbTime7.setSelected(resultSet.getBoolean("time7"));
                cbTime8.setSelected(resultSet.getBoolean("time8"));
                cbTime9.setSelected(resultSet.getBoolean("time9"));
                cbTime10.setSelected(resultSet.getBoolean("time10"));
                cbTime11.setSelected(resultSet.getBoolean("time11"));
                cbTime12.setSelected(resultSet.getBoolean("time12"));
                cbTime13.setSelected(resultSet.getBoolean("time13"));
                cbTime14.setSelected(resultSet.getBoolean("time14"));
                cbTime15.setSelected(resultSet.getBoolean("time15"));
                cbTime16.setSelected(resultSet.getBoolean("time16"));
                cbTime17.setSelected(resultSet.getBoolean("time17"));
                tfResult.setText(resultSet.getString("Result"));
                System.out.println(id);
            }

        } catch (SQLException ex) {
        }
        System.out.println("loaded");
    }

    private void chooseSpecialityOption() {
        try {
            String queryString = "select * from Speciality WHERE sName ='" + speciality + "'";
            ResultSet resultSet = stmt.executeQuery(queryString);
            while (resultSet.next()) {
                specialitiesList.getSelectionModel().select(resultSet.getInt("ID") - 1);
            }
        } catch (SQLException ex) {
        }
    }

    private void fillListsWeek() {
        list.clear();
        int ida = 0;
        int idb = 0;
        int idc = 0;
        Date date;
        Times time;
        String result;
        try {
            String queryString = "SELECT * FROM Appointments WHERE (((Appointments.appDate) Between Date()-6 And Date()+6));";
            ResultSet resultSet = stmt.executeQuery(queryString);
            ResultSetMetaData rsMetaData = resultSet.getMetaData();

            while (resultSet.next()) {
                for (int i = 1; i < rsMetaData.getColumnCount(); i = i + 15) {
                    ida = resultSet.getInt(i);
                    idb = resultSet.getInt(i + 1);
                    idc = resultSet.getInt(i + 2);
                    date = resultSet.getDate(i + 3);
//                    time = new Times(resultSet.getBoolean(i + 4), resultSet.getBoolean(i + 5), resultSet.getBoolean(i + 6), resultSet.getBoolean(i + 7), resultSet.getBoolean(i + 8), resultSet.getBoolean(i + 9), resultSet.getBoolean(i + 10), resultSet.getBoolean(i + 11), resultSet.getBoolean(i + 12), resultSet.getBoolean(i + 13), resultSet.getBoolean(i + 14));
                    Times asz = new Times();

                    result = resultSet.getString(i + 15);
                    list.add(new Appointment(ida, idb, idc, date, asz, result));

                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(CalVBox.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void fillList() {
        list.clear();

        int ida = 0;
        int idb = 0;
        int idc = 0;
        Date date;
        Times time;
        String result;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
            String queryString = "SELECT * FROM Appointments WHERE (((Appointments.appDate) = #" + formatter.format(datePicker.getValue()) + "#));";
            ResultSet resultSet = stmt.executeQuery(queryString);
            ResultSetMetaData rsMetaData = resultSet.getMetaData();

            while (resultSet.next()) {
                for (int i = 1; i < rsMetaData.getColumnCount(); i = i + 15) {
                    ida = resultSet.getInt(i);
                    idb = resultSet.getInt(i + 1);
                    idc = resultSet.getInt(i + 2);
                    date = resultSet.getDate(i + 3);
//                    time = new Times(resultSet.getBoolean(i + 4), resultSet.getBoolean(i + 5), resultSet.getBoolean(i + 6), resultSet.getBoolean(i + 7), resultSet.getBoolean(i + 8), resultSet.getBoolean(i + 9), resultSet.getBoolean(i + 10), resultSet.getBoolean(i + 11), resultSet.getBoolean(i + 12), resultSet.getBoolean(i + 13), resultSet.getBoolean(i + 14));
                    Times asz = new Times();

                    result = resultSet.getString(i + 15);
                    list.add(new Appointment(ida, idb, idc, date, asz, result));

                }
            }
            tableView.getItems().setAll(list);
        } catch (SQLException ex) {
            Logger.getLogger(CalVBox.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deleteAppointment() {

        Appointment sApp = tableView.getSelectionModel().getSelectedItem();

        try {
            String queryString5 = "DELETE FROM Appointments "
                    + "WHERE (ID='" + sApp.getApptId() + "')";
            stmt.executeUpdate(queryString5);

        } catch (SQLException ex) {
        }
        System.out.println("done");
    }
}
