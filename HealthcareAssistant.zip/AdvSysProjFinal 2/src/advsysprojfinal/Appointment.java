/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advsysprojfinal;

import java.util.Date;

/**
 *
 * @author aasim
 */
public class Appointment {

    private int apptId = 0;
    private int patId = 0;
    private int docId = 0;
    private Date date;
    private Times time = new Times();
    private String results;

    public Appointment() {
    }

    public Appointment(int apptId, int patId, int docId, Date date, Times time, String results) {
        this.apptId = apptId;
        this.patId = patId;
        this.docId = docId;
        this.date = date;
        this.time = time;
        this.results = results;
    }

    public int getApptId() {
        return apptId;
    }

    public void setApptId(int apptId) {
        this.apptId = apptId;
    }

    public int getPatId() {
        return patId;
    }

    public void setPatId(int patId) {
        this.patId = patId;
    }

    public int getDocId() {
        return docId;
    }

    public void setDocId(int docId) {
        this.docId = docId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Times getTime() {
        return time;
    }

    public void setDate(Times time) {
        this.time = time;
    }

    public String getResults() {
        return results;
    }

    public void setResults(String results) {
        this.results = results;
    }
}
